from multiprocessing import Pool
import time
import itertools as it
from pprint import pprint
import numpy as np
from sklearn import (preprocessing)
import sys

def cantor(m,n):
    return(0.5*(m+n)*(m+n+1)+m)

