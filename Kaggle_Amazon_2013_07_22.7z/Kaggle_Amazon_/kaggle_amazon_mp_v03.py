from sklearn import (metrics, cross_validation, preprocessing)
from csv_reader import csvReader
from skl_preped_models import (skl_models, paramaters, selected_features, greedy_features, param_grid_dict)
from multiprocessing import Pool
import numpy as np
import itertools as it
import time
import cPickle as pickle

from ml_helpers import *

def single_cv(data):
    model, X_train, y_train, seed = data
    cv = cross_validation.train_test_split(X_train, y_train, test_size=.20, random_state=seed)
    X_train_cv, X_test_cv, y_train_cv, y_test_cv = cv
    
    model.fit(X_train_cv, y_train_cv) 
    preds = model.predict_proba(X_test_cv)[:, 1]

    fpr, tpr, _ = metrics.roc_curve(y_test_cv, preds)
    roc_auc = metrics.auc(fpr, tpr)
    return(roc_auc)

def setup_and_fit_model(data): #model, X, y, X_cv, y_cv, score_func, test_params):
    model, X, y, score_func, test_params, f_set, cv_iter = data
    #model.set_params(**test_params)
    sum_score = 0
    for i in range(cv_iter):
        cv = cross_validation.train_test_split(X, y, test_size=.20, random_state=46*(i+1))
        sum_score += model_test([model, cv, score_func, test_params])
    return([sum_score/cv_iter, test_params, f_set])

def model_test(data):
    model, cv, score_func, test_params = data
    X_cv, X_test_cv, y_cv, y_test_cv = cv
    model.set_params(**test_params)
    model.fit(X_cv, y_cv)
    score = score_func(y_test_cv, model.predict_proba(X_test_cv)[:, 1])
    return(score)

def multiprocessor(func, args, processors):
    tasks, time_start = len(args), time.time()
    if tasks > 12: print('Starting pooled operation of %i tasks' % tasks)
    pool    = Pool(processes=processors)
    results = pool.map_async(func, args)
    pool.close()
    percent_last = 0
    while (True):
        if (results.ready()): break
        remaining = results._number_left
        time_elapsed = (time.time() - time_start)/60
        percent = (float(tasks - remaining) / float(tasks) * 100)
        if percent - percent_last > 20:
            if tasks > 12: print("    %.1f min - %i remaining - %.0f%%" % (time_elapsed, remaining, percent))
            percent_last = percent
        time.sleep(60*5)
    return(results.get())

def hyper_parameterisator(model, X, y, params_dicts, cv_iter, score_func=metrics.auc_score, n_jobs=None, f_set = ['all']):
    print('Starting grid search')
    keys, param_list, setup_and_fit = [], [], []
    if f_set[0] == 'all': X = one_hot_encoding(X)
    else:                 X = one_hot_encoding(X[:,f_set])
    
    for params_dict in params_dicts:
        for key, params in params_dict.items():
            keys.append(key)
            param_list.append(params)
        param_grid = list(it.product(*param_list))
        
        for params in param_grid:
            test_params = {}
            for i, param in enumerate(params):
                test_params[keys[i]] = param
            setup_and_fit.append([model, X, y, score_func, test_params, f_set, cv_iter])
    
    results = multiprocessor(setup_and_fit_model, setup_and_fit, n_jobs)
    return(process_results(results, keys))

def feature_selector(model, X, y, test_params, cv_iter, score_func=metrics.auc_score, n_jobs=8):
    print('Starting feature selection on %i features' %len(X[0]))
    sets, setup_and_fit = [], []
    for i in range(len(X[0])):
        #if i < 4: continue  
        for f_set in list(it.combinations(range(len(X[0])),i+1)):
            sets.append(f_set)
    for f_set in sets:
        for test_param in test_params:
            X_en = one_hot_encoding(X[:,f_set])
            setup_and_fit.append([model, X_en, y, score_func, test_param, f_set, cv_iter])
    
    print('Testing %i feature sets' % len(sets))
    results = multiprocessor(setup_and_fit_model, setup_and_fit, n_jobs)
    return(process_results(results, test_params[0].keys()))

def greedy_feature_selector(model, X, y, test_params, cv_iter=5, score_func=metrics.auc_score, seed=36):
    features, num_features, time_start = [], len(X[0]), time.time()
    print('Starting feature selection on %i features' %num_features)
    score_max = 0
    for i in range(num_features): 
        data_sets = []
        test = features + [i]
        #print(test)
        
        X_en = one_hot_encoding(X[:,test])
        for j in range(cv_iter):
            cv = cross_validation.train_test_split(X_en, y, test_size=.20, random_state=seed*j)
            data_sets.append([model, cv, score_func, test_params[0]])        
        results = multiprocessor(model_test, data_sets, cv_iter)
        score = np.mean(results)
        if score > score_max: 
            score_max = score
            features  = test
        print('  auc: %.4f - %i min - %i%% - using features: %s'
              % (score_max, (time.time() - time_start)/60, float(i) / float(num_features) * 100, ', '.join(map(str, features))))
    return(score_max, test_params[0], features)

def feature_builder(X, max_comb, pickle_file=None):
    print('Building features')
    rows, cols = len(X), len(X[0])
    sets = []
    for i in range(cols):
        if i >= max_comb: continue
        for f_set in list(it.combinations(range(cols),i+1)): 
            sets.append(f_set)
    X_new = np.empty((rows,len(sets)))
    for i,f_set in enumerate(sets):
        if len(f_set) == 1: 
            X_new[:,i] = X[:,f_set[0]]
            continue
        X_set = X[:,f_set]
        X_set_en = label_encoder(X_set)
        X_new_col = cantorer(X_set_en)
        X_new_col_en = label_encoder(X_new_col)
        X_new[:,i] = X_new_col_en
    print('Built %i new features, giving %i total' %(len(sets) - cols, len(X_new[0])))
    if pickle_file != None: pickle.dump(X_new, open(pickle_file, 'wb'), protocol=2)
    return(X_new)

if __name__ == '__main__':
    directory   = 'D:\Cooper\Google Drive\Kaggle_Amazon\data' #WINDOWS
    #directory   = 'C:\Google Drive\Kaggle_Amazon\data' #WINDOWS 2
    #directory   = '/Users/cooperoelrichs/Google Drive/Kaggle_Amazon/data' #MAC
    training    = 'train_8.csv'
    testing     = 'test_8.csv'
    results     = 'results.csv'
    extended_data = 'extended_data.p'
    y_train, X_train, index_test, X_test  = get_data(directory, training, testing)
    train_len = len(y_train)
    
    cv_iter, seed = 6, 103
    
    for i, (model_name, model) in enumerate(skl_models):
        #if model_name != 'svc_rbf': continue
        #if model_name != 'SGD_C_lr' and model_name != 'lr': continue
        if i > 0: continue
        test_params = paramaters[model_name]
        #f_set = selected_features['lr']
        
        t_now = time.time()
        
        """Create extended features"""
        f_set = greedy_features[-1]
        print(len(f_set))
        #X_extended = feature_builder(np.vstack((X_train, X_test)), 8, directory + '/' + extended_data)
        X_extended = pickle.load(open(directory + '/' + extended_data, "rb"))
        X_train_ext, X_test_ext = X_extended[:train_len], X_extended[train_len:]
        
        """Test models"""
        #res  = setup_and_fit_model([model, one_hot_encoding(X_train), y_train, metrics.auc_score, test_params[0], f_set, 6])
        
        """Create new models"""
        #res = hyper_parameterisator(model, X_train_ext, y_train, param_grid_dict[model_name], cv_iter, n_jobs=10, f_set=f_set)
        #res = feature_selector(model, X_train, y_train, test_params, cv_iter=cv_iter, score_func=metrics.auc_score, n_jobs=10)
        res = greedy_feature_selector(model, X_train_ext, y_train, test_params, cv_iter, metrics.auc_score, seed)
        roc_auc, best_params, best_features = res ; elapsed = time.time() - t_now
        print "AUC (model: %s, t: %.2f min): %f" % (model_name, elapsed/60, roc_auc)
        print("-- Best parameters - %s" % best_params)
        print("-- Best features - %s" % best_features)
        
        create_submission(model, X_train_ext, X_test_ext, y_train, best_params, best_features, directory, 'results_%s_%i.csv' %(model_name, i))
        
        
        
        
        
